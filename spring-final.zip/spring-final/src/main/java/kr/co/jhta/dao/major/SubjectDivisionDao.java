package kr.co.jhta.dao.major;

import kr.co.jhta.vo.SubjectDivision;

public interface SubjectDivisionDao {

	void addDivision (SubjectDivision division);
}
