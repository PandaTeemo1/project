package kr.co.jhta.vo;

public class Sessioncheck {
	
	private String check; // 0 관리자 1 교수 2 학생
	
	public Sessioncheck() {	}
	
	public String getCheck() {
		return check;
	}
	public void setCheck(String check) {
		this.check = check;
	}
	
	public Sessioncheck(String check) {
		super();
		this.check = check;
	}
	

	
	
	
	
	

}
