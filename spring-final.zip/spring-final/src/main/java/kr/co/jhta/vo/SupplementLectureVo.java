package kr.co.jhta.vo;

public class SupplementLectureVo {

	private int collegeNo;
	private String collegeCode;
	private String collegeName;
	private String majorCode;
	
	
	public int getCollegeNo() {
		return collegeNo;
	}
	public void setCollegeNo(int collegeNo) {
		this.collegeNo = collegeNo;
	}
	public String getCollegeCode() {
		return collegeCode;
	}
	public void setCollegeCode(String collegeCode) {
		this.collegeCode = collegeCode;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public String getMajorCode() {
		return majorCode;
	}
	public void setMajorCode(String majorCode) {
		this.majorCode = majorCode;
	}
	
	
}
