package kr.co.jhta.dao.appli;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface ChangeMajorDao {

}
