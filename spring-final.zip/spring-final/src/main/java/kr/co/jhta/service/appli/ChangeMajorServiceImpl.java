package kr.co.jhta.service.appli;

import org.springframework.stereotype.Service;

@Service
public class ChangeMajorServiceImpl implements ChangeMajorService{
	
	
	
}
