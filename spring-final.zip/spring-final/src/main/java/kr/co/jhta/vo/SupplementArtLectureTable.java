package kr.co.jhta.vo;

public class SupplementArtLectureTable {

	private String professorId;
	private String professorName;
	private int professorNo;
	private String professorRegister;
	private int subjectNo;
	private String subjectName;
	private int subjectScore;
	private String subjectPassed;
	
	
	
	public String getProfessorId() {
		return professorId;
	}
	public void setProfessorId(String professorId) {
		this.professorId = professorId;
	}
	public String getProfessorName() {
		return professorName;
	}
	public void setProfessorName(String professorName) {
		this.professorName = professorName;
	}
	public int getProfessorNo() {
		return professorNo;
	}
	public void setProfessorNo(int professorNo) {
		this.professorNo = professorNo;
	}
	public String getProfessorRegister() {
		return professorRegister;
	}
	public void setProfessorRegister(String professorRegister) {
		this.professorRegister = professorRegister;
	}
	public int getSubjectNo() {
		return subjectNo;
	}
	public void setSubjectNo(int subjectNo) {
		this.subjectNo = subjectNo;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public int getSubjectScore() {
		return subjectScore;
	}
	public void setSubjectScore(int subjectScore) {
		this.subjectScore = subjectScore;
	}
	public String getSubjectPassed() {
		return subjectPassed;
	}
	public void setSubjectPassed(String subjectPassed) {
		this.subjectPassed = subjectPassed;
	}
	
	
}
