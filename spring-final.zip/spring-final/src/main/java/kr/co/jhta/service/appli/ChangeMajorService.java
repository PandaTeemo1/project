package kr.co.jhta.service.appli;

public interface ChangeMajorService {

}
