package kr.co.jhta.service.appli;

import kr.co.jhta.vo.appli.Leave;

public interface ReinstatementService {
	
	void addNewReinByLeave(Leave leave);

}
