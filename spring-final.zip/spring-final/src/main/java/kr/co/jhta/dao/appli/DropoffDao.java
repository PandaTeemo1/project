package kr.co.jhta.dao.appli;

import kr.co.jhta.vo.hakjuk.Dropoff;

public interface DropoffDao {
	
	void addNewDropoff(Dropoff drop);

}
