package kr.co.jhta.vo.appli;

public class ChangeMajorForm {

}
