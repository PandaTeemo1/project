package kr.co.jhta.dao.appli;


public interface DisenrollmentDao {

}
