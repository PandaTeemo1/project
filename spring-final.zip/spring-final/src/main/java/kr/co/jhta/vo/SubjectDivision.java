package kr.co.jhta.vo;

public class SubjectDivision {

	private int no;
	private Subject subjectNo;
	private int divisionNo;
	private int limitNumber;
	private String divisionProfessor;
	
	public SubjectDivision() {
		// TODO Auto-generated constructor stub
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public Subject getSubjectNo() {
		return subjectNo;
	}

	public void setSubjectNo(Subject subjectNo) {
		this.subjectNo = subjectNo;
	}

	public int getDivisionNo() {
		return divisionNo;
	}

	public void setDivisionNo(int divisionNo) {
		this.divisionNo = divisionNo;
	}

	public int getLimitNumber() {
		return limitNumber;
	}

	public void setLimitNumber(int limitNumber) {
		this.limitNumber = limitNumber;
	}

	public String getDivisionProfessor() {
		return divisionProfessor;
	}

	public void setDivisionProfessor(String divisionProfessor) {
		this.divisionProfessor = divisionProfessor;
	}
	
	
}
