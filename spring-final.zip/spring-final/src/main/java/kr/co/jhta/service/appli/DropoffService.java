package kr.co.jhta.service.appli;

import kr.co.jhta.vo.hakjuk.Dropoff;

public interface DropoffService {
	
	void addNewDropoffService(Dropoff drop);
	
	

}
